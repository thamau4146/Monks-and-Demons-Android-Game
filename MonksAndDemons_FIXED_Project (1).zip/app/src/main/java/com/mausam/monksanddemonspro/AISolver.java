
package com.mausam.monksanddemonspro;

import java.util.*;

public class AISolver {

    public static List<String> solve(){

        List<String> sol = new ArrayList<>();

        sol.add("1 Monk + 1 Demon → Right");
        sol.add("1 Monk ← Left");
        sol.add("2 Demons → Right");
        sol.add("1 Demon ← Left");
        sol.add("2 Monks → Right");

        return sol;
    }
}
