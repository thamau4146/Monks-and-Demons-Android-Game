
package com.mausam.monksanddemonspro;

public class GameState {

    int monksLeft = 3;
    int demonsLeft = 3;

    public void moveMonk(){
        if(monksLeft>0) monksLeft--;
    }

    public void moveDemon(){
        if(demonsLeft>0) demonsLeft--;
    }

    public String getState(){
        return "Monks Left: "+monksLeft+"\nDemons Left: "+demonsLeft;
    }
}
