
package com.mausam.monksanddemonspro;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class GameActivity extends AppCompatActivity {

    TextView stateText;
    GameState state;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        state = new GameState();

        stateText = findViewById(R.id.stateText);
        Button monk = findViewById(R.id.moveMonk);
        Button demon = findViewById(R.id.moveDemon);
        Button ai = findViewById(R.id.aiSolve);

        update();

        monk.setOnClickListener(v -> {
            state.moveMonk();
            update();
        });

        demon.setOnClickListener(v -> {
            state.moveDemon();
            update();
        });

        ai.setOnClickListener(v -> {
            List<String> sol = AISolver.solve();
            String s="";
            for(String step:sol) s+=step+"\n";
            stateText.setText(s);
        });
    }

    void update(){
        stateText.setText(state.getState());
    }
}
